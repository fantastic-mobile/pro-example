import{C as e,Ct as t,H as n,rt as r,w as i,x as a,y as o}from"./vue.runtime.esm-bundler-DOMO_wpA.js";import{Y as s,et as c,x as l}from"./src-C_SUC8up.js";import{t as u}from"./AppPageLayout-CilNLEuS.js";var d={},f={class:`flex gap-4`};function p(t,r){let i=s;return n(),a(`div`,f,[e(i,{src:`https://fantastic-mobile.hurui.me/logo.png`}),e(i,{src:`https://fantastic-mobile.hurui.me/logo.png`,shape:`square`}),e(i,{src:``,fallback:`Hooray`})])}var m=c(d,[[`render`,p]]),h=`<template>
  <div class="flex gap-4">
    <FmAvatar src="https://fantastic-mobile.hurui.me/logo.png" />
    <FmAvatar src="https://fantastic-mobile.hurui.me/logo.png" shape="square" />
    <FmAvatar src="" fallback="Hooray" />
  </div>
</template>
`,g=i({__name:`index`,setup(i){return(i,a)=>{let s=l,c=u;return n(),o(c,{navbar:``,"navbar-start-side":`back`},{default:r(()=>[e(s,{code:t(h)},{default:r(()=>[e(m)]),_:1},8,[`code`])]),_:1})}}});export{g as default};