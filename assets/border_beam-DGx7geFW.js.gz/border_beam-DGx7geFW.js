import{C as e,Ct as t,H as n,rt as r,v as i,w as a,x as o,y as s}from"./vue.runtime.esm-bundler-DMY3hWtO.js";import{H as c,P as l,V as u}from"./components-CBpXWGFQ.js";import{t as d}from"./AppPageLayout-S1V78StU.js";var f={},p={class:`border rounded-lg flex-center h-50 relative overflow-hidden`};function m(t,r){let a=u;return n(),o(`div`,p,[r[0]||(r[0]=i(`span`,{class:`text-3xl text-transparent leading-none font-semibold text-center pointer-events-none whitespace-pre-wrap from-black to-gray-300/80 bg-gradient-to-b bg-clip-text dark:from-white dark:to-slate-900/10`},` Fantastic-mobile `,-1)),e(a,{size:250,duration:12e3,delay:1e3,"border-width":2})])}var h=c(f,[[`render`,m]]),g=`<template>
  <div class="border rounded-lg flex-center h-50 relative overflow-hidden">
    <span class="text-3xl text-transparent leading-none font-semibold text-center pointer-events-none whitespace-pre-wrap from-black to-gray-300/80 bg-gradient-to-b bg-clip-text dark:from-white dark:to-slate-900/10">
      Fantastic-mobile
    </span>
    <FmBorderBeam
      :size="250"
      :duration="12000"
      :delay="1000"
      :border-width="2"
    />
  </div>
</template>
`,_=a({__name:`index`,setup(i){return(i,a)=>{let o=l,c=d;return n(),s(c,{navbar:``,"navbar-start-side":`back`},{default:r(()=>[e(o,{code:t(g)},{default:r(()=>[e(h)]),_:1},8,[`code`])]),_:1})}}});export{_ as default};