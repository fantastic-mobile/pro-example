import{C as e,Ct as t,H as n,S as r,lt as i,mt as a,rt as o,v as s,w as c,x as l,y as u}from"./vue.runtime.esm-bundler-BBr2zMyZ.js";import{B as d,H as f,I as p,O as m,V as h,W as g,g as _}from"./components-DK30L-iF.js";import{t as v}from"./AppPageLayout-BwSv5Viu.js";var y={};function b(t,i){let a=h,s=d,c=f;return n(),u(c,null,{default:o(()=>[e(s,null,{default:o(()=>[e(a,{name:`i-mdi:eye`,class:`size-4`}),i[0]||(i[0]=r(` 查看详情 `,-1))]),_:1}),e(s,null,{default:o(()=>[e(a,{name:`i-mdi:pencil`,class:`size-4`}),i[1]||(i[1]=r(` 编辑 `,-1))]),_:1}),e(s,null,{default:o(()=>[e(a,{name:`i-mdi:delete`,class:`size-4`}),i[2]||(i[2]=r(` 删除 `,-1))]),_:1})]),_:1})}var x=g(y,[[`render`,b]]),S=`<template>
  <FmButtonGroup>
    <FmButton>
      <FmIcon name="i-mdi:eye" class="size-4" />
      查看详情
    </FmButton>
    <FmButton>
      <FmIcon name="i-mdi:pencil" class="size-4" />
      编辑
    </FmButton>
    <FmButton>
      <FmIcon name="i-mdi:delete" class="size-4" />
      删除
    </FmButton>
  </FmButtonGroup>
</template>
`,C={};function w(t,i){let a=h,s=d,c=f;return n(),u(c,{orientation:`vertical`},{default:o(()=>[e(s,null,{default:o(()=>[e(a,{name:`i-mdi:eye`,class:`size-4`}),i[0]||(i[0]=r(` 查看详情 `,-1))]),_:1}),e(s,null,{default:o(()=>[e(a,{name:`i-mdi:pencil`,class:`size-4`}),i[1]||(i[1]=r(` 编辑 `,-1))]),_:1}),e(s,null,{default:o(()=>[e(a,{name:`i-mdi:delete`,class:`size-4`}),i[2]||(i[2]=r(` 删除 `,-1))]),_:1})]),_:1})}var T=g(C,[[`render`,w]]),E=`<template>
  <FmButtonGroup orientation="vertical">
    <FmButton>
      <FmIcon name="i-mdi:eye" class="size-4" />
      查看详情
    </FmButton>
    <FmButton>
      <FmIcon name="i-mdi:pencil" class="size-4" />
      编辑
    </FmButton>
    <FmButton>
      <FmIcon name="i-mdi:delete" class="size-4" />
      删除
    </FmButton>
  </FmButtonGroup>
</template>
`,D={},O={class:`flex flex-col gap-4 items-start`};function k(t,i){let a=h,c=d,u=f;return n(),l(`div`,O,[e(u,{separator:``},{default:o(()=>[e(c,null,{default:o(()=>[e(a,{name:`i-mdi:eye`,class:`size-4`}),i[0]||(i[0]=r(` 查看详情 `,-1))]),_:1}),e(c,null,{default:o(()=>[e(a,{name:`i-mdi:pencil`,class:`size-4`}),i[1]||(i[1]=r(` 编辑 `,-1))]),_:1}),e(c,null,{default:o(()=>[e(a,{name:`i-mdi:delete`,class:`size-4`}),i[2]||(i[2]=r(` 删除 `,-1))]),_:1})]),_:1}),e(u,{orientation:`vertical`,separator:``},{default:o(()=>[e(c,null,{default:o(()=>[e(a,{name:`i-mdi:eye`,class:`size-4`}),i[3]||(i[3]=r(` 查看详情 `,-1))]),_:1}),e(c,null,{default:o(()=>[e(a,{name:`i-mdi:pencil`,class:`size-4`}),i[4]||(i[4]=r(` 编辑 `,-1))]),_:1}),e(c,null,{default:o(()=>[e(a,{name:`i-mdi:delete`,class:`size-4`}),i[5]||(i[5]=r(` 删除 `,-1))]),_:1})]),_:1}),i[9]||(i[9]=s(`p`,null,`按钮如果为 outline 则无需设置分割线`,-1)),e(u,null,{default:o(()=>[e(c,{variant:`outline`},{default:o(()=>[e(a,{name:`i-mdi:eye`,class:`size-4`}),i[6]||(i[6]=r(` 查看详情 `,-1))]),_:1}),e(c,{variant:`outline`},{default:o(()=>[e(a,{name:`i-mdi:pencil`,class:`size-4`}),i[7]||(i[7]=r(` 编辑 `,-1))]),_:1}),e(c,{variant:`outline`},{default:o(()=>[e(a,{name:`i-mdi:delete`,class:`size-4`}),i[8]||(i[8]=r(` 删除 `,-1))]),_:1})]),_:1})])}var A=g(D,[[`render`,k]]),j=`<template>
  <div class="flex flex-col gap-4 items-start">
    <FmButtonGroup separator>
      <FmButton>
        <FmIcon name="i-mdi:eye" class="size-4" />
        查看详情
      </FmButton>
      <FmButton>
        <FmIcon name="i-mdi:pencil" class="size-4" />
        编辑
      </FmButton>
      <FmButton>
        <FmIcon name="i-mdi:delete" class="size-4" />
        删除
      </FmButton>
    </FmButtonGroup>
    <FmButtonGroup orientation="vertical" separator>
      <FmButton>
        <FmIcon name="i-mdi:eye" class="size-4" />
        查看详情
      </FmButton>
      <FmButton>
        <FmIcon name="i-mdi:pencil" class="size-4" />
        编辑
      </FmButton>
      <FmButton>
        <FmIcon name="i-mdi:delete" class="size-4" />
        删除
      </FmButton>
    </FmButtonGroup>
    <p>按钮如果为 outline 则无需设置分割线</p>
    <FmButtonGroup>
      <FmButton variant="outline">
        <FmIcon name="i-mdi:eye" class="size-4" />
        查看详情
      </FmButton>
      <FmButton variant="outline">
        <FmIcon name="i-mdi:pencil" class="size-4" />
        编辑
      </FmButton>
      <FmButton variant="outline">
        <FmIcon name="i-mdi:delete" class="size-4" />
        删除
      </FmButton>
    </FmButtonGroup>
  </div>
</template>
`,M={};function N(t,i){let a=d,s=f,c=h;return n(),u(s,null,{default:o(()=>[e(s,null,{default:o(()=>[e(a,{variant:`outline`},{default:o(()=>[...i[0]||(i[0]=[r(` 1 `,-1)])]),_:1}),e(a,{variant:`outline`},{default:o(()=>[...i[1]||(i[1]=[r(` 2 `,-1)])]),_:1}),e(a,{variant:`outline`},{default:o(()=>[...i[2]||(i[2]=[r(` 3 `,-1)])]),_:1}),e(a,{variant:`outline`},{default:o(()=>[...i[3]||(i[3]=[r(` 4 `,-1)])]),_:1}),e(a,{variant:`outline`},{default:o(()=>[...i[4]||(i[4]=[r(` 5 `,-1)])]),_:1})]),_:1}),e(s,null,{default:o(()=>[e(a,{variant:`outline`,size:`icon`},{default:o(()=>[e(c,{name:`i-ep:arrow-left`})]),_:1}),e(a,{variant:`outline`,size:`icon`},{default:o(()=>[e(c,{name:`i-ep:arrow-right`})]),_:1})]),_:1})]),_:1})}var P=g(M,[[`render`,N]]),F=`<template>
  <FmButtonGroup>
    <FmButtonGroup>
      <FmButton variant="outline">
        1
      </FmButton>
      <FmButton variant="outline">
        2
      </FmButton>
      <FmButton variant="outline">
        3
      </FmButton>
      <FmButton variant="outline">
        4
      </FmButton>
      <FmButton variant="outline">
        5
      </FmButton>
    </FmButtonGroup>
    <FmButtonGroup>
      <FmButton variant="outline" size="icon">
        <FmIcon name="i-ep:arrow-left" />
      </FmButton>
      <FmButton variant="outline" size="icon">
        <FmIcon name="i-ep:arrow-right" />
      </FmButton>
    </FmButtonGroup>
  </FmButtonGroup>
</template>
`,I={class:`flex flex-col gap-4 items-start`},L=c({__name:`_demo5`,setup(r){let s=a(`CNY`);return(r,a)=>{let c=m,u=h,p=d,g=f,v=_;return n(),l(`div`,I,[e(g,null,{default:o(()=>[e(c),e(p,{variant:`outline`,size:`icon`},{default:o(()=>[e(u,{name:`i-ep:search`})]),_:1})]),_:1}),e(g,null,{default:o(()=>[e(v,{modelValue:t(s),"onUpdate:modelValue":a[0]||(a[0]=e=>i(s)?s.value=e:null),options:[{label:`¥`,value:`CNY`},{label:`$`,value:`USD`},{label:`€`,value:`EUR`}],class:`gap-1 w-inherit`},null,8,[`modelValue`]),e(c,{placeholder:`10.00`})]),_:1})])}}}),R=`<script setup lang="ts">
const currency = ref('CNY')
<\/script>

<template>
  <div class="flex flex-col gap-4 items-start">
    <FmButtonGroup>
      <FmInput />
      <FmButton variant="outline" size="icon">
        <FmIcon name="i-ep:search" />
      </FmButton>
    </FmButtonGroup>
    <FmButtonGroup>
      <FmSelect
        v-model="currency"
        :options="[
          { label: '¥', value: 'CNY' },
          { label: '$', value: 'USD' },
          { label: '€', value: 'EUR' },
        ]"
        class="gap-1 w-inherit"
      />
      <FmInput placeholder="10.00" />
    </FmButtonGroup>
  </div>
</template>
`,z=c({__name:`index`,setup(r){return(r,i)=>{let a=p,c=v;return n(),u(c,{navbar:``,"navbar-start-side":`back`},{default:o(()=>[s(`div`,null,[e(a,{code:t(S)},{default:o(()=>[e(x)]),_:1},8,[`code`]),e(a,{title:`垂直`,code:t(E)},{default:o(()=>[e(T)]),_:1},8,[`code`]),e(a,{title:`分割线`,code:t(j)},{default:o(()=>[e(A)]),_:1},8,[`code`]),e(a,{title:`嵌套`,code:t(F)},{default:o(()=>[e(P)]),_:1},8,[`code`]),e(a,{title:`与其他组件组合`,code:t(R)},{default:o(()=>[e(L)]),_:1},8,[`code`])])]),_:1})}}});export{z as default};