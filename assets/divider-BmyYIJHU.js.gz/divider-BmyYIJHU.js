import{C as e,Ct as t,H as n,rt as r,w as i,y as a}from"./vue.runtime.esm-bundler-DOMO_wpA.js";import{x as o}from"./src-C_SUC8up.js";import{t as s}from"./AppPageLayout-CilNLEuS.js";import{t as c}from"./demo1-whBj_acO.js";var l=`<template>
  <FmDivider>center</FmDivider>
  <FmDivider position="start">
    left
  </FmDivider>
  <FmDivider position="end">
    right
  </FmDivider>
</template>
`,u=i({__name:`index`,setup(i){return(i,u)=>{let d=o,f=s;return n(),a(f,{navbar:``,"navbar-start-side":`back`},{default:r(()=>[e(d,{code:t(l)},{default:r(()=>[e(c)]),_:1},8,[`code`])]),_:1})}}});export{u as default};