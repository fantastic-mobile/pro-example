import{C as e,Ct as t,H as n,S as r,rt as i,v as a,w as o,x as s,y as c}from"./vue.runtime.esm-bundler-DOMO_wpA.js";import{_ as l,et as u,x as d}from"./src-C_SUC8up.js";import{t as f}from"./AppPageLayout-CilNLEuS.js";var p={},m={class:`flex h-50 items-center justify-center`},h={class:`text-sm text-neutral-600 font-semibold mx-auto dark:text-neutral-400`};function g(t,i){let o=l;return n(),s(`div`,m,[a(`div`,h,[i[0]||(i[0]=r(` Vue.js 是一款 `,-1)),e(o,{words:[`渐进式`,`易上手的`,`高性能`,`多功能`],duration:3e3,class:`text-sm !text-primary`}),i[1]||(i[1]=r(` JavaScript 框架 `,-1)),i[2]||(i[2]=a(`div`,{class:`mt-4`},` 用于构建现代 Web 应用 `,-1))])])}var _=u(p,[[`render`,g]]),v=`<template>
  <div class="flex h-50 items-center justify-center">
    <div class="text-sm text-neutral-600 font-semibold mx-auto dark:text-neutral-400">
      Vue.js 是一款
      <FmFlipWords
        :words="['渐进式', '易上手的', '高性能', '多功能']"
        :duration="3000"
        class="text-sm !text-primary"
      />
      JavaScript 框架
      <div class="mt-4">
        用于构建现代 Web 应用
      </div>
    </div>
  </div>
</template>
`,y=o({__name:`index`,setup(r){return(r,a)=>{let o=d,s=f;return n(),c(s,{navbar:``,"navbar-start-side":`back`},{default:i(()=>[e(o,{code:t(v)},{default:i(()=>[e(_)]),_:1},8,[`code`])]),_:1})}}});export{y as default};