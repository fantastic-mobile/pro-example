import{_ as r}from"./index-d6ZB0Jya.js";import{_ as a}from"./index.vue_vue_type_script_setup_true_lang-DMxm4nWt.js";import i from"./demo1--qE-oxel.js";import{d as m,c as s,o as _,w as e,b as t,u as c}from"./index-BLP5v8hh.js";import"./index.vue_vue_type_script_setup_true_lang-Bk9FuQCK.js";const p=`<template>
  <FmDivider>center</FmDivider>
  <FmDivider position="start">
    left
  </FmDivider>
  <FmDivider position="end">
    right
  </FmDivider>
</template>
`,w=m({__name:"index",setup(d){return(f,u)=>{const n=a,o=r;return _(),s(o,{navbar:"","navbar-start-side":"back"},{default:e(()=>[t(n,{code:c(p)},{default:e(()=>[t(i)]),_:1},8,["code"])]),_:1})}}});export{w as default};
