import{_ as u}from"./index-d6ZB0Jya.js";import{_ as d}from"./index.vue_vue_type_script_setup_true_lang-DMxm4nWt.js";import{d as s,r as i,c as _,o as r,Y as f,u as c,i as v,w as t,b as a}from"./index-BLP5v8hh.js";import"./index.vue_vue_type_script_setup_true_lang-Bk9FuQCK.js";const x=s({__name:"_demo1",setup(m){const e=i("");return(p,n)=>{const o=f;return r(),_(o,{modelValue:c(e),"onUpdate:modelValue":n[0]||(n[0]=l=>v(e)?e.value=l:null),placeholder:"请输入内容"},null,8,["modelValue"])}}}),b=`<script setup lang="ts">
const value = ref('')
<\/script>

<template>
  <FmInput v-model="value" placeholder="请输入内容" />
</template>
`,h=s({__name:"index",setup(m){return(e,p)=>{const n=d,o=u;return r(),_(o,{navbar:"","navbar-start-side":"back"},{default:t(()=>[a(n,{code:c(b)},{default:t(()=>[a(x)]),_:1},8,["code"])]),_:1})}}});export{h as default};
