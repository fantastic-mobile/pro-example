import{d as o,h as t,j as n,k as r,o as a}from"./index-BoebyoP1.js";const p=o({__name:"reload",setup(s){const e=r();return t(()=>{e.go(-1)}),(c,u)=>(a(),n("div"))}});export{p as default};
