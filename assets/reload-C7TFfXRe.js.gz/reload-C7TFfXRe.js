import{d as o,g as t,j as n,o as r,k as a}from"./index-DSCegQmK.js";const p=o({__name:"reload",setup(s){const e=t();return n(()=>{e.go(-1)}),(c,u)=>(r(),a("div"))}});export{p as default};
