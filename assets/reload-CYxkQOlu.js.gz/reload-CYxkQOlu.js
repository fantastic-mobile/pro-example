import{d as o,g as t,j as n,k as r,o as a}from"./index-BLP5v8hh.js";const p=o({__name:"reload",setup(s){const e=t();return n(()=>{e.go(-1)}),(c,u)=>(a(),r("div"))}});export{p as default};
