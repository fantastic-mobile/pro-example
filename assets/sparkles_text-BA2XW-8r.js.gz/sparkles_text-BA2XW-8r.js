import{C as e,Ct as t,H as n,rt as r,v as i,w as a,y as o}from"./vue.runtime.esm-bundler-DOMO_wpA.js";import{et as s,s as c,x as l}from"./src-C_SUC8up.js";import{t as u}from"./AppPageLayout-CilNLEuS.js";var d={};function f(e,t){let r=c;return n(),o(r,{text:`Fantastic-mobile`,class:`text-2xl`})}var p=s(d,[[`render`,f]]),m=`<template>
  <FmSparklesText text="Fantastic-mobile" class="text-2xl" />
</template>
`,h={};function g(e,t){let r=c;return n(),o(r,{text:`Fantastic-mobile`,"sparkles-count":50,class:`text-2xl`})}var _=s(h,[[`render`,g]]),v=`<template>
  <FmSparklesText text="Fantastic-mobile" :sparkles-count="50" class="text-2xl" />
</template>
`,y={};function b(e,t){let r=c;return n(),o(r,{text:`Fantastic-mobile`,colors:{first:`#FF6B6B`,second:`#4ECDC4`},class:`text-2xl`})}var x=s(y,[[`render`,b]]),S=`<template>
  <FmSparklesText text="Fantastic-mobile" :colors="{ first: '#FF6B6B', second: '#4ECDC4' }" class="text-2xl" />
</template>
`,C=a({__name:`index`,setup(a){return(a,s)=>{let c=l,d=u;return n(),o(d,{navbar:``,"navbar-start-side":`back`},{default:r(()=>[i(`div`,null,[e(c,{code:t(m)},{default:r(()=>[e(p)]),_:1},8,[`code`]),e(c,{title:`数量`,code:t(v)},{default:r(()=>[e(_)]),_:1},8,[`code`]),e(c,{title:`颜色`,code:t(S)},{default:r(()=>[e(x)]),_:1},8,[`code`])])]),_:1})}}});export{C as default};